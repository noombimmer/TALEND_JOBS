﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using webserv.Models;

namespace webserv.Controllers
{
    public class QAD_PT_MSTRController : ApiController
    {
        private MTLDBEntities db = new MTLDBEntities();

        // GET: api/QAD_PT_MSTR
        public HttpResponseMessage GetQAD_PT_MSTR()
        {
            return GetQAD_PT_MSTR(db,"","");
        }

        // GET: api/QAD_PT_MSTR/5
        [ResponseType(typeof(QAD_PT_MSTR))]
        public IHttpActionResult GetQAD_PT_MSTR(string id)
        {
            QAD_PT_MSTR qAD_PT_MSTR = db.QAD_PT_MSTR.Find(id);
            if (qAD_PT_MSTR == null)
            {
                return NotFound();
            }

            return Ok(qAD_PT_MSTR);
        }

        // PUT: api/QAD_PT_MSTR/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutQAD_PT_MSTR(string id, QAD_PT_MSTR qAD_PT_MSTR)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != qAD_PT_MSTR.pt_part)
            {
                return BadRequest();
            }

            db.Entry(qAD_PT_MSTR).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!QAD_PT_MSTRExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/QAD_PT_MSTR
        [ResponseType(typeof(QAD_PT_MSTR))]
        public IHttpActionResult PostQAD_PT_MSTR(QAD_PT_MSTR qAD_PT_MSTR)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.QAD_PT_MSTR.Add(qAD_PT_MSTR);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (QAD_PT_MSTRExists(qAD_PT_MSTR.pt_part))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = qAD_PT_MSTR.pt_part }, qAD_PT_MSTR);
        }

        // DELETE: api/QAD_PT_MSTR/5
        [ResponseType(typeof(QAD_PT_MSTR))]
        public IHttpActionResult DeleteQAD_PT_MSTR(string id)
        {
            QAD_PT_MSTR qAD_PT_MSTR = db.QAD_PT_MSTR.Find(id);
            if (qAD_PT_MSTR == null)
            {
                return NotFound();
            }

            db.QAD_PT_MSTR.Remove(qAD_PT_MSTR);
            db.SaveChanges();

            return Ok(qAD_PT_MSTR);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool QAD_PT_MSTRExists(string id)
        {
            return db.QAD_PT_MSTR.Count(e => e.pt_part == id) > 0;
        }
        public HttpResponseMessage GetQAD_PT_MSTR(MTLDBEntities entities, string Domain, string PartNumber)
        {
            try
            {
                var resourceModelList = entities.getProduct(Domain, PartNumber).ToList();

                if (resourceModelList.Count == 0)
                {
                    return this.Request.CreateResponse<string>(HttpStatusCode.NotFound, "No resources found.");
                }

                return this.Request.CreateResponse<List<QAD_PT_MSTR>>(HttpStatusCode.OK, resourceModelList, "application/json");

            }
            catch (Exception ex)
            {
                return this.Request.CreateResponse<string>(HttpStatusCode.InternalServerError, ex.ToString());
            }
        }

    }
}